package com.slapps.sinhalatranslator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

public class Translator extends AppCompatActivity {
    String SYMBOL;
    TextView tvLang;
    String texttobetranslated;
    ImageView clip ,share,mClearText;
    private AdView mAdView;
    public static String[] languages={"Select target language","Albanian", "Azerbaijani", "Belaurian", "Bulgarian", "Czech", "Dutch", "English","Finnish",
            "French", "German", "Hungarian", "Italian", "Latvian", "Lithuanian", "Norwegian",
            "Polish","Portuguese", "Romanian", "Russian", "Serbian", "Sinhala","Slovak", "Spanish", "Swedish", "Turkish", "Ukrainian"
    };
    public static String[] langsym={"","sq", "az", "be", "bg", "cs", "nl","en", "fi", "fr", "de", "hu", "it", "lv", "lt", "no", "pl", "pt", "ro", "ru", "sr", "si","sk", "es", "sv", "tr", "uk"
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);//will hide the title
        getSupportActionBar().hide();
        setContentView(R.layout.activity_translator);
        Spinner spinner=findViewById(R.id.spinner);
        ArrayAdapter<String> languageadapter= new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,languages);
        spinner.setAdapter(languageadapter);
        spinner.setSelection(21);
        final EditText etLang = findViewById(R.id.etLang);
        Button btnTranslate= findViewById(R.id.btnTrans);

        clip = (ImageView) findViewById(R.id.image_speak1);
        share = (ImageView) findViewById(R.id.share1);
        mClearText = (ImageView) findViewById(R.id.clear_text1);

        tvLang=findViewById(R.id.tvLang);
        tvLang.setMovementMethod(new ScrollingMovementMethod());
        etLang.setText(getIntent().getStringExtra("result"));

        mAdView = findViewById(R.id.adView1);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                SYMBOL=langsym[i];
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        btnTranslate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isConnected()) {
                    texttobetranslated = etLang.getText().toString();
                    Translate(texttobetranslated,SYMBOL);
                } else {
                    Toast.makeText(getApplicationContext(), "No Internet Connection", Toast.LENGTH_LONG).show();
                }

            }
        });

        clip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText("label", tvLang.getText().toString());
                clipboard.setPrimaryClip(clip);
            }
        });

        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s = tvLang.getText().toString();
                Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
                sharingIntent.setType("text/plain");
                sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Subject Here");
                sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, s);
                startActivity(Intent.createChooser(sharingIntent, "Share text via"));
            }
        });

        mClearText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etLang.setText("");
                tvLang.setText("");
            }
        });
    }
    void Translate(String ttbt,String symbol){
        TranslatorBackGroundTask tbt = new TranslatorBackGroundTask(new TranslatorBackGroundTask.MyAsyncTaskListener() {
            @Override
            public void onPostExecute(String s) {
                tvLang.setText(s);
            }
        });
        tbt.execute(ttbt,symbol);

    }

    public boolean isConnected() {
        boolean connected = false;
        try {
            ConnectivityManager cm = (ConnectivityManager)getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo nInfo = cm.getActiveNetworkInfo();
            connected = nInfo != null && nInfo.isAvailable() && nInfo.isConnected();
            return connected;
        } catch (Exception e) {
            Log.e("Connectivity Exception", e.getMessage());
        }
        return connected;
    }
}
