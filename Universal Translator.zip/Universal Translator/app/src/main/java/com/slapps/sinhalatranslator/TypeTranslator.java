package com.slapps.sinhalatranslator;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class TypeTranslator extends AppCompatActivity {

    String SYMBOL;
    TextView tvLang;
    String texttobetranslated;
    ImageView clip ,share,mClearText;
    EditText etLang;
    private AdView mAdView;
    private String mLanguageCodeFrom = "en";
    private static final int REQ_CODE_SPEECH_INPUT = 1;

    public static String[] languages={"Select target language","Albanian", "Azerbaijani", "Belaurian", "Bulgarian", "Czech", "Dutch", "English","Finnish",
            "French", "German", "Hungarian", "Italian", "Latvian", "Lithuanian", "Norwegian",
            "Polish","Portuguese", "Romanian", "Russian", "Serbian", "Sinhala","Slovak", "Spanish", "Swedish", "Turkish", "Ukrainian"
    };
    public static String[] langsym={"","sq", "az", "be", "bg", "cs", "nl","en", "fi", "fr", "de", "hu", "it", "lv", "lt", "no", "pl", "pt", "ro", "ru", "sr", "si","sk", "es", "sv", "tr", "uk"
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);//will hide the title
        getSupportActionBar().hide();
        setContentView(R.layout.activity_type_translator);
        Spinner spinner=findViewById(R.id.spinner3);
        clip = (ImageView) findViewById(R.id.image_speak);
        share = (ImageView) findViewById(R.id.share);
        mClearText = (ImageView) findViewById(R.id.clear_text);
        ImageView mImageListen = (ImageView) findViewById(R.id.image_listen);
        ArrayAdapter<String> languageadapter= new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,languages);
        spinner.setAdapter(languageadapter);
        spinner.setSelection(21);
        etLang = findViewById(R.id.text_input);
        Button btnTranslate= findViewById(R.id.button7);
        tvLang=findViewById(R.id.text_translated);
        tvLang.setMovementMethod(new ScrollingMovementMethod());
        etLang.setText(getIntent().getStringExtra("result"));


        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                SYMBOL=langsym[i];
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        btnTranslate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (isConnected()) {
                    texttobetranslated = etLang.getText().toString();
                    Translate(texttobetranslated,SYMBOL);
                    hideKeybaord(view);


                } else {
                    Toast.makeText(getApplicationContext(), "No Internet Connection", Toast.LENGTH_LONG).show();
                }


            }
        });

        clip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText("label", tvLang.getText().toString());
                clipboard.setPrimaryClip(clip);
            }
        });

        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s = tvLang.getText().toString();
                Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
                sharingIntent.setType("text/plain");
                sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Subject Here");
                sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, s);
                startActivity(Intent.createChooser(sharingIntent, "Share text via"));
            }
        });

        mClearText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                etLang.setText("");
                tvLang.setText("");
            }
        });

        mImageListen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, mLanguageCodeFrom);
                intent.putExtra(RecognizerIntent.EXTRA_PROMPT, getString(R.string.speech_prompt));
                try {
                    startActivityForResult(intent, REQ_CODE_SPEECH_INPUT);
                } catch (ActivityNotFoundException a) {
                    Toast.makeText(getApplicationContext(), getString(R.string.language_not_supported), Toast.LENGTH_SHORT).show();
                }
            }
        });


    }



    void Translate(String ttbt,String symbol){
        TranslatorBackGroundTask tbt = new TranslatorBackGroundTask(new TranslatorBackGroundTask.MyAsyncTaskListener() {
            @Override
            public void onPostExecute(String s) {
                tvLang.setText(s);
            }
        });
        tbt.execute(ttbt,symbol);

    }

    public boolean isConnected() {
        boolean connected = false;
        try {
            ConnectivityManager cm = (ConnectivityManager)getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo nInfo = cm.getActiveNetworkInfo();
            connected = nInfo != null && nInfo.isAvailable() && nInfo.isConnected();
            return connected;
        } catch (Exception e) {
            Log.e("Connectivity Exception", e.getMessage());
        }
        return connected;
    }

    private void hideKeybaord(View v) {
        InputMethodManager inputMethodManager = (InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(v.getApplicationWindowToken(),0);
    }

    //  RESULT OF SPEECH INPUT
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case REQ_CODE_SPEECH_INPUT: {
                if (resultCode == RESULT_OK && null != data) {
                    /*
                            Dialog box to show list of processed Speech to text results
                            User selects matching text to display in chat
                     */
                    final Dialog match_text_dialog = new Dialog(TypeTranslator.this);
                    match_text_dialog.setContentView(R.layout.dialog_matches_frag);
                    match_text_dialog.setTitle(getString(R.string.select_matching_text));
                    ListView textlist = (ListView)match_text_dialog.findViewById(R.id.list);
                    final ArrayList<String> matches_text = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                    ArrayAdapter<String> adapter = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,matches_text);
                    textlist.setAdapter(adapter);
                    textlist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                        @Override
                        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                            etLang.setText(matches_text.get(position));
                            match_text_dialog.dismiss();
                        }
                    });
                    match_text_dialog.show();
                    break;
                }
            }
        }
    }





}
